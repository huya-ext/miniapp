import { AppRegistry } from 'react-native';

import demoRnStreamer from './demoRnStreamer/App';

AppRegistry.registerComponent('demoRnStreamer', () => demoRnStreamer);