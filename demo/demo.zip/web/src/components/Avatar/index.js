import React from 'react'
import './index.scss'

const Avatar = () => {
    return (
      <div className="avatar">
      	<img src={require("./icon.png")}></img>
      </div>
    )
}

export default Avatar