import { AppRegistry } from 'react-native';

import demoRn from './demoRn/App';

AppRegistry.registerComponent('demoRn', () => demoRn);