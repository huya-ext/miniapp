
import React from 'react'
import { render } from 'react-dom'

import 'antd/dist/antd.css'
import HyExtDev from './hy-ext-dev'

render(
  <HyExtDev />,
  document.getElementById('root')
)
